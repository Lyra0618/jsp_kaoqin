$(function () {
    // 加载弹出层
    layui.use(['form','element'], function() {
        layer = layui.layer;  // 获取 layer 模块
        element = layui.element;  // 获取 element 模块
    });

    // 触发事件
    var tab = {
        // 新增一个 Tab 项
        tabAdd: function(title, url, id){
            element.tabAdd('xbs_tab', {
                title: title,  // Tab 项的标题
                content: '<iframe tab-id="'+id+'" frameborder="0" src="'+url+'" scrolling="yes" class="x-iframe"></iframe>',  // Tab 项的内容，嵌入 iframe
                id: id  // Tab 项的 ID
            })
        },
        // 删除指定 Tab 项
        tabDelete: function(othis){
            element.tabDelete('xbs_tab', '44'); // 删除 ID 为 44 的 Tab 项
            othis.addClass('layui-btn-disabled');  // 将按钮设为不可点击状态
        },
        // 切换到指定 Tab 项
        tabChange: function(id){
            element.tabChange('xbs_tab', id); // 切换到 ID 为 id 的 Tab 项
        }
    };


    // 左侧菜单点击事件
    $('.left-nav #nav li').click(function (event) {
        if($(this).children('.sub-menu').length){
            if($(this).hasClass('open')){
                $(this).removeClass('open');  // 关闭子菜单
                $(this).find('.nav_right').html('&#xe697;');  // 修改图标
                $(this).children('.sub-menu').stop().slideUp();  // 隐藏子菜单
                $(this).siblings().children('.sub-menu').slideUp();  // 隐藏其他子菜单
            } else {
                $(this).addClass('open');  // 打开子菜单
                $(this).children('a').find('.nav_right').html('&#xe6a6;');  // 修改图标
                $(this).children('.sub-menu').stop().slideDown();  // 显示子菜单
                $(this).siblings().children('.sub-menu').stop().slideUp();  // 隐藏其他子菜单
                $(this).siblings().find('.nav_right').html('&#xe697;');  // 修改其他图标
                $(this).siblings().removeClass('open');  // 关闭其他菜单
            }
        } else {
            var url = $(this).children('a').attr('_href');  // 获取链接(staff.jsp)
            var title = $(this).find('cite').html();  // 获取标题(员工管理)
            var index  = $('.left-nav #nav li').index($(this));  // 获取索引

            // 判断是否已经打开该 Tab
            for (var i = 0; i <$('.x-iframe').length; i++) {
                if($('.x-iframe').eq(i).attr('tab-id') == index + 1){
                    tab.tabChange(index + 1);  // 切换到该 Tab
                    event.stopPropagation();  // 阻止事件传播
                    return;
                }
            };

            tab.tabAdd(title, url, index + 1);  // 新增 Tab
            tab.tabChange(index + 1);  // 切换到该 Tab
        }

        event.stopPropagation();  // 阻止事件传播
    });
});

            /**
             *  1.检查是否有子菜单，如果有则展开或收起子菜单。
                2.获取点击项的URL和标题。
                3.检查是否已有相同的Tab项，如果有则切换到该Tab项。
                4.如果没有，则添加新的Tab项并切换到该Tab项。
             */


    // 左侧菜单切换事件
    $('.container .left_open i').click(function(event) {
        if($('.left-nav').css('left') == '0px'){
            $('.left-nav').animate({left: '-221px'}, 100);  // 隐藏左侧菜单
            $('.page-content').animate({left: '0px'}, 100);  // 调整内容区域
            $('.page-content-bg').hide();  // 隐藏背景
        } else {
            $('.left-nav').animate({left: '0px'}, 100);  // 显示左侧菜单
            $('.page-content').animate({left: '221px'}, 100);  // 调整内容区域
            if($(window).width() < 768){
                $('.page-content-bg').show();  // 显示背景
            }
        }
    });

    // 背景点击事件
    $('.page-content-bg').click(function(event) {
        $('.left-nav').animate({left: '-221px'}, 100);  // 隐藏左侧菜单
        $('.page-content').animate({left: '0px'}, 100);  // 调整内容区域
        $(this).hide();  // 隐藏背景
    });

    // Tab 关闭按钮点击事件
    $('.layui-tab-close').click(function(event) {
        $('.layui-tab-title li').eq(0).find('i').remove();  // 移除第一个 Tab 的关闭按钮
    });

    // 隐藏所有子栏目
    $("tbody.x-cate tr[fid!='0']").hide();
    // 栏目多级显示效果
    $('.x-show').click(function () {
        if($(this).attr('status') == 'true'){
            $(this).html('&#xe625;');  // 修改图标
            $(this).attr('status', 'false');  // 修改状态
            var cateId = $(this).parents('tr').attr('cate-id');
            $("tbody tr[fid=" + cateId + "]").show();  // 显示子栏目
        } else {
            var cateIds = [];
            $(this).html('&#xe623;');  // 修改图标
            $(this).attr('status', 'true');  // 修改状态
            var cateId = $(this).parents('tr').attr('cate-id');
            getCateId(cateId);
            for (var i in cateIds) {
                $("tbody tr[cate-id=" + cateIds[i] + "]").hide().find('.x-show').html('&#xe623;').attr('status', 'true');  // 隐藏子栏目
            }
        }
    });

tableCheck = {
    // 初始化表格多选
    init:function() {
        $(".layui-form-checkbox").click(function(event) {
            if($(this).hasClass('layui-form-checked')){
                $(this).removeClass('layui-form-checked');  // 取消选中
                if($(this).hasClass('header')){
                    $(".layui-form-checkbox").removeClass('layui-form-checked');  // 取消所有选中
                }
            } else {
                $(this).addClass('layui-form-checked');  // 选中
                if($(this).hasClass('header')){
                    $(".layui-form-checkbox").addClass('layui-form-checked');  // 选中所有
                }
            }
        });
    },
    // 获取选中的数据
    getData:function() {
        var obj = $(".layui-form-checked").not('.header');  // 排除 header
        var arr = [];
        obj.each(function(index, el) {
            arr.push(obj.eq(index).attr('data-id'));  // 获取 data-id 并加入数组
        });
        return arr;  // 返回选中的数据 ID 数组
    }
}

// 开启表格多选
tableCheck.init();


var cateIds = [];
function getCateId(cateId) {
    
    $("tbody tr[fid="+cateId+"]").each(function(index, el) {
        id = $(el).attr('cate-id');
        cateIds.push(id);
        getCateId(id);
    });
}

                    /*弹出层*/
                    /*
                        参数解释：
                        title   标题
                        url     请求的url
                        id      需要操作的数据id
                        w       弹出层宽度（缺省调默认值）
                        h       弹出层高度（缺省调默认值）
                    */
                    function x_admin_show(title,url,w,h){
                        if (title == null || title == '') {
                            title=false;
                        };
                        if (url == null || url == '') {
                            url="404.html";
                        };
                        if (w == null || w == '') {
                            w=($(window).width()*0.9);
                        };
                        if (h == null || h == '') {
                            h=($(window).height() - 50);
                        };
                        //使用了 Layui 框架中的 layer.open 方法来创建一个带有 iframe 内容的弹出窗口。
                        layer.open({
                            type: 2,//表示 iframe 类型
                            area: [w+'px', h +'px'],//设置弹出窗口的宽度和高度
                            fix: false, //表示窗口不固定在页面上，可以随页面滚动。
                            maxmin: true,// 表示显示最大化和最小化按钮。
                            shadeClose: true,//表示点击遮罩区域可以关闭弹出窗口
                            shade:0.4,//0.4 表示遮罩的透明度为 0.4。
                            title: title,//设置弹出窗口的标题。
                            content: url//设置弹出窗口内容的 URL，这个 URL 会被嵌入到 iframe 中
                        });
                    }

/*关闭弹出框口*/
function x_admin_close(){
    var index = parent.layer.getFrameIndex(window.name);
    parent.layer.close(index);
}



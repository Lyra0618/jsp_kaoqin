package nuc.ss.domain;

/**
 * @author
 * @date 2024年06月24日 15:37
 */
public class Department {
    // 部门编号
    private Long id;
    // 部门名称
    private String name;
    // 上级部门编号
    private Long parentId;
    // 部门地址路径
    private String depPath;
    // 是否启用
    private Integer enabled;
    // 是否为父部门
    private Integer isParent;
    // 上级部门名称
    private String parentName;

    public String getParentName() {
        return parentName;
    }

    public void setParentName(String parentName) {
        this.parentName = parentName;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Long getParentId() {
        return parentId;
    }

    public void setParentId(Long parentId) {
        this.parentId = parentId;
    }

    public String getDepPath() {
        return depPath;
    }

    public void setDepPath(String depPath) {
        this.depPath = depPath;
    }

    public Integer getEnabled() {
        return enabled;
    }

    public void setEnabled(Integer enabled) {
        this.enabled = enabled;
    }

    public Integer getIsParent() {
        return isParent;
    }

    public void setIsParent(Integer isParent) {
        this.isParent = isParent;
    }
}

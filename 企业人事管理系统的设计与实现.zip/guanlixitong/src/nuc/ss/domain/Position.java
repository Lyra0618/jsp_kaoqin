package nuc.ss.domain;

import java.util.Date;

/**
 * 职位
 * @author
 * @date 2024年06月24日 15:38
 */
public class Position {

      private Long id;
      // 职位名称
      private String name;
      private Date createDate;
      // 状态
      private String enabled;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Date getCreateDate() {
        return createDate;
    }

    public void setCreateDate(Date createDate) {
        this.createDate = createDate;
    }

    public String getEnabled() {
        return enabled;
    }

    public void setEnabled(String enabled) {
        this.enabled = enabled;
    }
}

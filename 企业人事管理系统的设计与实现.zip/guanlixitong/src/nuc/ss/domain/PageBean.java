package nuc.ss.domain;

import java.util.ArrayList;
import java.util.List;

/**
 * 分页 实体类
 * @param <T> 泛型类型，用于表示分页的数据类型
 * 作用：PageBean类的作用是用来封装分页数据。它包含当前页码、每页显示的条数、总条数和总页数等分页信息。
 *       同时，它还包含多个列表，用来存放不同类型的分页数据，如员工列表、部门列表、岗位列表、薪资列表和合同列表等。
 *        通过这个类，可以很方便地管理和传递分页数据，使代码更加清晰和易于维护。
 */
public class PageBean<T> {
	private int currentPage; // 当前页码
	private int currentCount; // 每页显示的条数
	private int totalCount; // 总条数
	private int totalPage; // 总页数

	private List<T> staffList = new ArrayList<T>(); // 员工列表
	private List<T> departmentList = new ArrayList<>(); // 部门列表
	private List<T> positionList = new ArrayList<>(); // 岗位列表
	private List<T> salaryList = new ArrayList<>(); // 薪资列表
	private List<T> contractList = new ArrayList<>(); // 合同列表

	/**
	 * 获取员工列表
	 * @return 员工列表
	 */
	public List<T> getStaffList() {
		return staffList;
	}

	/**
	 * 设置员工列表
	 * @param staffList 员工列表
	 */
	public void setStaffList(List<T> staffList) {
		this.staffList = staffList;
	}

	/**
	 * 获取当前页码
	 * @return 当前页码
	 */
	public int getCurrentPage() {
		return currentPage;
	}

	/**
	 * 设置当前页码
	 * @param currentPage 当前页码
	 */
	public void setCurrentPage(int currentPage) {
		this.currentPage = currentPage;
	}

	/**
	 * 获取每页显示的条数
	 * @return 每页显示的条数
	 */
	public int getCurrentCount() {
		return currentCount;
	}

	/**
	 * 设置每页显示的条数
	 * @param currentCount 每页显示的条数
	 */
	public void setCurrentCount(int currentCount) {
		this.currentCount = currentCount;
	}

	/**
	 * 获取总条数
	 * @return 总条数
	 */
	public int getTotalCount() {
		return totalCount;
	}

	/**
	 * 设置总条数
	 * @param totalCount 总条数
	 */
	public void setTotalCount(int totalCount) {
		this.totalCount = totalCount;
	}

	/**
	 * 获取总页数
	 * @return 总页数
	 */
	public int getTotalPage() {
		return totalPage;
	}

	/**
	 * 设置总页数
	 * @param totalPage 总页数
	 */
	public void setTotalPage(int totalPage) {
		this.totalPage = totalPage;
	}

	/**
	 * 获取部门列表
	 * @return 部门列表
	 */
	public List<T> getDepartmentList() {
		return departmentList;
	}

	/**
	 * 设置部门列表
	 * @param departmentList 部门列表
	 */
	public void setDepartmentList(List<T> departmentList) {
		this.departmentList = departmentList;
	}

	/**
	 * 获取岗位列表
	 * @return 岗位列表
	 */
	public List<T> getPositionList() {
		return positionList;
	}

	/**
	 * 设置岗位列表
	 * @param positionList 岗位列表
	 */
	public void setPositionList(List<T> positionList) {
		this.positionList = positionList;
	}

	/**
	 * 获取薪资列表
	 * @return 薪资列表
	 */
	public List<T> getSalaryList() {
		return salaryList;
	}

	/**
	 * 设置薪资列表
	 * @param salaryList 薪资列表
	 */
	public void setSalaryList(List<T> salaryList) {
		this.salaryList = salaryList;
	}

	/**
	 * 获取合同列表
	 * @return 合同列表
	 */
	public List<T> getContractList() {
		return contractList;
	}

	/**
	 * 设置合同列表
	 * @param contractList 合同列表
	 */
	public void setContractList(List<T> contractList) {
		this.contractList = contractList;
	}
}

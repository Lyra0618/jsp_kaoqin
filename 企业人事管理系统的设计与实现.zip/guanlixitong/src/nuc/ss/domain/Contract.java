package nuc.ss.domain;

/**
 * 合同
 * @author
 * @date 2024年06月25日 20:24
 */
public class Contract {

    // 编号
    private String id;
    // 人员编号
    private String staffId;
    // 合同编号
    private String contractCode;
    // 合同类型
    private String contractType;
    // 开始日期
    private String beginDate;
    // 结束日期
    private String endDate;
    // 人员名称
    private String staffName;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getStaffId() {
        return staffId;
    }

    public void setStaffId(String staffId) {
        this.staffId = staffId;
    }

    public String getContractCode() {
        return contractCode;
    }

    public void setContractCode(String contractCode) {
        this.contractCode = contractCode;
    }

    public String getContractType() {
        return contractType;
    }

    public void setContractType(String contractType) {
        this.contractType = contractType;
    }

    public String getBeginDate() {
        return beginDate;
    }

    public void setBeginDate(String beginDate) {
        this.beginDate = beginDate;
    }

    public String getEndDate() {
        return endDate;
    }

    public void setEndDate(String endDate) {
        this.endDate = endDate;
    }

    public String getStaffName() {
        return staffName;
    }

    public void setStaffName(String staffName) {
        this.staffName = staffName;
    }
}

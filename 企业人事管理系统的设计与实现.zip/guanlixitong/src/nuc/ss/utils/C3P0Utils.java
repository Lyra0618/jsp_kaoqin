package nuc.ss.utils;
import java.sql.Connection;//数据库连接
import java.sql.SQLException;//异常

import javax.sql.DataSource;//数据源接口

import com.mchange.v2.c3p0.ComboPooledDataSource;//C3P0 提供的一个实现了连接池功能的数据源类。

public class C3P0Utils {
	//用于初始化和配置连接池
	private static ComboPooledDataSource dataSource = new ComboPooledDataSource();

	//提供对连接池的访问接口，它允许外部代码获取到配置好的数据源，以便执行数据库操作。
	public static DataSource getDataSource() {
		return dataSource;
	}

	//这个方法从连接池中获取一个数据库连接。如果获取连接时发生异常，则捕获 SQLException 并抛出一个运行时异常 RuntimeException。
	public static Connection getConnection() {
		try {
			return dataSource.getConnection();
		} catch (SQLException e) {
			throw new RuntimeException(e);
		}
	}
}

/*
通过创建工具类 C3P0Utils 来封装获取数据库连接的方法，可以简化代码、统一管理、提高代码复用性、确保资源正确管理，
并且统一处理异常和配置。这种封装方式有助于提高代码的可维护性和可靠性，使得数据库连接管理更加高效和规范。
 */
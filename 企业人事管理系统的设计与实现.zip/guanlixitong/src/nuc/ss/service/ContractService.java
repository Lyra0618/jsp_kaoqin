package nuc.ss.service;

import nuc.ss.dao.ContractDao;
import nuc.ss.domain.Contract;
import nuc.ss.domain.PageBean;

import java.sql.SQLException;
import java.util.List;

/**
 * 合同 服务类
 * @date 2024年06月25日 20:29
 */
public class ContractService {

    /**
     * 分页查询
     * @param currentPage 当前页码
     * @param currentCount 每页显示的条数
     * @return PageBean 包含分页信息和当前页的数据
     * @throws SQLException
     */
    public PageBean<Contract> findPageBean(int currentPage, int currentCount) throws SQLException {
        PageBean pageBean = new PageBean(); // 创建PageBean对象
        pageBean.setCurrentPage(currentPage); // 设置当前页码
        pageBean.setCurrentCount(currentCount); // 设置每页显示的条数
        ContractDao dao = new ContractDao(); // 创建ContractDao对象
        int totalCount = dao.Count().intValue(); // 获取总条数
        pageBean.setTotalCount(totalCount); // 设置总条数
        int totalPage = (int) Math.ceil(1.0 * totalCount / currentCount); // 计算总页数
        pageBean.setTotalPage(totalPage); // 设置总页数
        int index = (currentPage - 1) * currentCount; // 计算当前页的起始索引
        List<Contract> contractList = dao.findAllContractListForPageBean(index, currentCount); // 获取当前页的数据
        pageBean.setContractList(contractList); // 设置当前页的数据
        return pageBean; // 返回PageBean对象
    }

    /**
     * 查询全部
     * @return 合同列表
     * @throws SQLException
     */
    public List<Contract> findAll() throws SQLException {
        ContractDao dao = new ContractDao(); // 创建ContractDao对象
        return dao.findAllContract(); // 查询并返回所有合同数据
    }

    /**
     * 统计条数
     * @return 合同总数
     * @throws SQLException
     */
    public Long Count() throws SQLException {
        ContractDao dao = new ContractDao(); // 创建ContractDao对象
        return dao.Count(); // 查询并返回合同总数
    }

    /**
     * 删除
     * @param id 合同ID
     * @throws SQLException
     */
    public void del(String id) throws SQLException {
        ContractDao dao = new ContractDao(); // 创建ContractDao对象
        dao.delete(id); // 删除指定ID的合同
    }

    /**
     * 新增
     * @param contract 合同对象
     * @throws SQLException
     */
    public void add(Contract contract) throws SQLException {
        ContractDao dao = new ContractDao(); // 创建ContractDao对象
        dao.add(contract); // 添加新的合同
    }

    /**
     * 更新
     * @param contract 合同对象
     * @throws SQLException
     */
    public void update(Contract contract) throws SQLException {
        ContractDao dao = new ContractDao(); // 创建ContractDao对象
        dao.update(contract); // 更新合同数据
    }
}

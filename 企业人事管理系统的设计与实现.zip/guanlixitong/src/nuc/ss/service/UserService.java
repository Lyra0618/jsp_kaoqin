package nuc.ss.service;


import java.sql.SQLException;

import nuc.ss.dao.UserDao;
import nuc.ss.domain.Staff;

public class UserService {

	public Staff login(String name, String password) throws SQLException {
		// TODO Auto-generated method stub
		UserDao dao = new UserDao();
		return dao.login(name, password);
	}

	/**
	 * 修改密码
	 * @param staffId
	 * @param password
	 * @throws SQLException
	 */
	public void updatePassword(String staffId, String password) throws SQLException {
		UserDao dao = new UserDao();
		dao.updatePassword(staffId, password);
	}
}

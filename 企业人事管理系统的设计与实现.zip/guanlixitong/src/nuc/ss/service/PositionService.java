package nuc.ss.service;

import nuc.ss.dao.PositionDao;
import nuc.ss.domain.PageBean;
import nuc.ss.domain.Position;

import java.sql.SQLException;
import java.util.List;

/**
 * 职位 业务层
 * @author
 * @date 2024年06月24日 15:56
 */
public class PositionService {

    /**
     * 分页查询
     * @param currentPage
     * @param currentCount
     * @return
     * @throws SQLException
     */
    public PageBean<Position> findPageBean(int currentPage, int currentCount) throws SQLException {
        PageBean pageBean = new PageBean();
        pageBean.setCurrentPage(currentPage);
        pageBean.setCurrentCount(currentCount);
        PositionDao dao = new PositionDao();
        int totalCount = dao.Count().intValue();
        pageBean.setTotalCount(totalCount);
        int totalPage = (int) Math.ceil(1.0*totalCount/currentCount);
        pageBean.setTotalPage(totalPage);
        int index = (currentPage-1)*currentCount;
        List<Position> jiaqishenqingList = dao.findAllPositionListForPageBean(index,currentCount);
        pageBean.setPositionList(jiaqishenqingList);
        return pageBean;
    }

    /**
     * 查询全部
     * @return
     * @throws SQLException
     */
    public List<Position> findAll() throws SQLException {
        PositionDao dao = new PositionDao();
        return dao.findAllPosition();
    }

    /**
     * 统计条数
     * @return
     * @throws SQLException
     */
    public Long Count() throws SQLException {
        PositionDao dao = new PositionDao();
        return dao.Count();
    }

    /**
     * 删除
     * @param id
     * @throws SQLException
     */
    public void del(String id) throws SQLException {
        // TODO Auto-generated method stub
        PositionDao dao = new PositionDao();
        dao.delete(id);
    }

    /**
     * 新增
     * @param j
     * @throws SQLException
     */
    public void add(Position j) throws SQLException {
        // TODO Auto-generated method stub
        PositionDao dao = new PositionDao();
        dao.add(j);
    }
    /**
     * 更新
     * @param j
     * @throws SQLException
     */
    public void update(Position j) throws SQLException {
        // TODO Auto-generated method stub
        PositionDao dao = new PositionDao();
        dao.update(j);
    }
}

package nuc.ss.service;

import java.sql.SQLException;
import java.util.List;

import nuc.ss.dao.StaffDao;
import nuc.ss.domain.PageBean;
import nuc.ss.domain.Staff;

/**
 * 员工 业务层
 */
public class StaffService {
	/**
	 * 分页查询
	 * @param currentPage 当前页码
	 * @param currentCount 每页显示的条数
	 * @return 包含员工列表的分页实体类
	 * @throws SQLException
	 */
	public PageBean<Staff> findPageBean(int currentPage, int currentCount) throws SQLException {
		// 创建 PageBean 对象，用于封装分页信息
		PageBean pageBean = new PageBean();

		// 设置当前页码
		pageBean.setCurrentPage(currentPage);

		// 设置每页显示的条数
		pageBean.setCurrentCount(currentCount);

		// 创建 StaffDao 对象
		StaffDao dao = new StaffDao();

		// 获取员工总条数
		int totalCount = dao.Count().intValue();

		// 设置员工总条数
		pageBean.setTotalCount(totalCount);

		// 计算总页数并设置总页数
		int totalPage = (int) Math.ceil(1.0 * totalCount / currentCount);

		pageBean.setTotalPage(totalPage);

		// 计算查询的起始索引
		int index = (currentPage - 1) * currentCount;

		// 获取当前页的员工列表
		List<Staff> staffList = dao.findAllStaffListForPageBean(index, currentCount);

		// 设置员工列表到 PageBean
		pageBean.setStaffList(staffList);

		// 返回 PageBean 对象
		return pageBean;
	}

	/**
	 * 查询全部员工
	 * @return 员工列表
	 * @throws SQLException
	 */
	public List<Staff> findAllStaff() throws SQLException {
		// 创建 StaffDao 对象
		StaffDao dao = new StaffDao();

		// 查询并返回所有员工
		return dao.findAllStaff();
	}

	/**
	 * 统计员工总条数
	 * @return 员工总条数
	 * @throws SQLException
	 */
	public Long Count() throws SQLException {
		// 创建 StaffDao 对象
		StaffDao dao = new StaffDao();

		// 查询并返回员工总条数
		return dao.Count();
	}

	/**
	 * 添加员工
	 * @param staff 员工对象
	 * @throws SQLException
	 */
	public void add(Staff staff) throws SQLException {
		// 创建 StaffDao 对象
		StaffDao dao = new StaffDao();

		// 调用 DAO 层的方法添加员工
		dao.add(staff);
	}

	/**
	 * 删除员工
	 * @param id 员工 ID
	 * @throws SQLException
	 */
	public void del(String id) throws SQLException {
		// 创建 StaffDao 对象
		StaffDao dao = new StaffDao();

		// 调用 DAO 层的方法删除员工
		dao.delete(id);
	}

	/**
	 * 更新员工信息
	 * @param staff 员工对象
	 * @throws SQLException
	 */
	public void update(Staff staff) throws SQLException {
		// 创建 StaffDao 对象
		StaffDao dao = new StaffDao();

		// 调用 DAO 层的方法更新员工信息
		dao.update(staff);
	}

	/**
	 * 根据员工 ID 查询员工
	 * @param id 员工 ID
	 * @return 员工对象
	 * @throws SQLException
	 */
	public Staff findById(Long id) throws SQLException {
		// 创建 StaffDao 对象
		StaffDao dao = new StaffDao();

		// 调用 DAO 层的方法根据员工 ID 查询员工
		return dao.findById(id);
	}
}

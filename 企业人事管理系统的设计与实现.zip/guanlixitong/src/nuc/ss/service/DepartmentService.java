package nuc.ss.service;

import nuc.ss.dao.DepartmentDao;
import nuc.ss.domain.Department;
import nuc.ss.domain.PageBean;

import java.sql.SQLException;
import java.util.List;

/**
 * 部门 业务层
 * @author
 * @date 2024年06月24日 15:52
 */
public class DepartmentService {

    /**
     * 分页查询
     * @param currentPage
     * @param currentCount
     * @return
     * @throws SQLException
     */
    public PageBean<Department> findPageBean(int currentPage, int currentCount) throws SQLException {
        PageBean pageBean = new PageBean();
        pageBean.setCurrentPage(currentPage);
        pageBean.setCurrentCount(currentCount);
        DepartmentDao dao = new DepartmentDao();
        int totalCount = dao.Count().intValue();
        pageBean.setTotalCount(totalCount);
        int totalPage = (int) Math.ceil(1.0*totalCount/currentCount);
        pageBean.setTotalPage(totalPage);
        int index = (currentPage-1)*currentCount;
        List<Department> jiaqishenqingList = dao.findAllDeptListForPageBean(index,currentCount);
        pageBean.setDepartmentList(jiaqishenqingList);
        return pageBean;
    }

    /**
     * 查询全部
     * @return
     * @throws SQLException
     */
    public List<Department> findAll() throws SQLException {
        DepartmentDao dao = new DepartmentDao();
        return dao.findAllDept();
    }

    /**
     * 统计条数
     * @return
     * @throws SQLException
     */
    public Long Count() throws SQLException {
        DepartmentDao dao = new DepartmentDao();
        return dao.Count();
    }

    /**
     * 删除
     * @param id
     * @throws SQLException
     */
    public void del(String id) throws SQLException {
        // TODO Auto-generated method stub
        DepartmentDao dao = new DepartmentDao();
        dao.delete(id);
    }

    /**
     * 新增
     * @param j
     * @throws SQLException
     */
    public void add(Department j) throws SQLException {
        // TODO Auto-generated method stub
        DepartmentDao dao = new DepartmentDao();
        dao.add(j);
    }

    /**
     * 更新
     * @param j
     * @throws SQLException
     */
    public void update(Department j) throws SQLException {
        // TODO Auto-generated method stub
        DepartmentDao dao = new DepartmentDao();
        dao.update(j);
    }
}

package nuc.ss.web;

import nuc.ss.domain.Department;
import nuc.ss.domain.PageBean;
import nuc.ss.service.DepartmentService;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.sql.SQLException;
import java.util.List;

/**
 * 部门列表
 * @author
 * @date 2024年06月24日 15:30
 */
public class DeptList extends HttpServlet {
    //定义一个唯一标识符，用于控制序列化版本。
    private static final long serialVersionUID = 1L;

    /**
     * @see HttpServlet#HttpServlet()
     */
    public DeptList() {
        super();
        // TODO Auto-generated constructor stub
    }

    /**
     * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
     */
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // TODO Auto-generated method stub
        DepartmentService service = new DepartmentService();
        String currentPageStr =request.getParameter("currentPage");
        if(currentPageStr==null) currentPageStr="1";
        int currentPage = Integer.parseInt(currentPageStr);
        int currentCount=4;
        Long count = null;
        PageBean<Department> pageBean = null;
        List<Department> staffList = null;
        try {
            pageBean = service.findPageBean(currentPage,currentCount);
            staffList = service.findAll();
            count = service.Count();
            request.setAttribute("pageBean", pageBean);
            request.setAttribute("deptList", staffList);
            request.setAttribute("count", count);
            request.getRequestDispatcher("view/views/user/dept/staff.jsp").forward(request, response);
        }catch (SQLException e) {
            e.printStackTrace();
        }
    }

    /**
     * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
     */
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // TODO Auto-generated method stub
        doGet(request, response);
    }
}

package nuc.ss.web;

import java.io.IOException;
import java.sql.SQLException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import nuc.ss.domain.PageBean;
import nuc.ss.domain.Staff;
import nuc.ss.service.StaffService;

/**
 * 查询人员信息列表
 * Servlet implementation class StaffList
 */
public class StaffList extends HttpServlet {
	private static final long serialVersionUID = 1L;

    /**
     * @see HttpServlet#HttpServlet()
     */
    public StaffList() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		StaffService service = new StaffService();
		/*
		currentPage 是分页功能中的一个约定参数，用于指示当前显示的页码。
		当用户点击分页导航中的页码链接时，URL 中会包含 currentPage 参数。例如，点击第二页时，URL 可能是 /StaffList?currentPage=2。
		 */
		//从请求参数中获取当前页码。
		String currentPageStr =request.getParameter("currentPage");
		//如果没有提供页码参数，默认设置为第一页。
		if(currentPageStr==null) currentPageStr="1";
		//将当前页码参数转换为整数。
		int currentPage = Integer.parseInt(currentPageStr);
		//设置每页显示条数
		int currentCount=4;

		//在分页功能中显示总记录数。
		Long count = null;
		//在前端页面上显示分页信息（如当前页码、总页数）。
		//显示当前页的员工数据列表。
		PageBean<Staff> pageBean = null;
		//提供给前端页面，用于显示所有员工的列表(未使用)
		List<Staff> staffList = null;
		try {
			pageBean = service.findPageBean(currentPage,currentCount);
			staffList = service.findAllStaff();
			count = service.Count();
			request.setAttribute("pageBean", pageBean);
			request.setAttribute("staffList", staffList);
			request.setAttribute("count", count);
			request.getRequestDispatcher("view/views/user/user/staff.jsp").forward(request, response);
		}catch (SQLException e) {
			e.printStackTrace();
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}

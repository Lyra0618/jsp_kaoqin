package nuc.ss.web;

import nuc.ss.domain.Department;
import nuc.ss.service.DepartmentService;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

/**
 * 修改部门
 * @author
 * @date 2024年06月24日 16:30
 */
public class DeptEdit extends HttpServlet {
    //定义一个唯一标识符，用于控制序列化版本。
    private static final long serialVersionUID = 1L;

    /**
     * @see HttpServlet#HttpServlet()
     */
    public DeptEdit() {
        super();
        // TODO Auto-generated constructor stub
    }

    /**
     * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
     */
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        request.setCharacterEncoding("UTF-8");
        String id = request.getParameter("id");//4
        String name = request.getParameter("name");//华北市场部
        String parentId = request.getParameter("parentId");//3
        String depPath = request.getParameter("depPath");//.1.2.3.5
        /*//是否有子部门
        String isParent = "1";
        if (parentId != "-1") {
            isParent = "0";
        }*/

        DepartmentService service = new DepartmentService();
        try {
            Department department = new Department();
            department.setId(Long.valueOf(id));
            department.setName(name);
            department.setParentId(Long.valueOf(parentId));
            department.setDepPath(depPath);
            /*department.setIsParent(Integer.valueOf(isParent));*/

            service.update(department);
            Thread.sleep(3000);
            response.sendRedirect(request.getContextPath() + "/DeptList");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
     */
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // TODO Auto-generated method stub
        doGet(request, response);
    }

}

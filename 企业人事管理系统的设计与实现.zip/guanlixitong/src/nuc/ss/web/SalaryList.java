package nuc.ss.web;

import nuc.ss.domain.PageBean;
import nuc.ss.domain.Position;
import nuc.ss.domain.Salary;
import nuc.ss.service.SalaryService;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.sql.SQLException;
import java.util.List;

/**
 * 查询薪资列表
 * @author
 * @date 2024年06月24日 16:41
 */
public class SalaryList extends HttpServlet {
    //定义一个唯一标识符，用于控制序列化版本。
    private static final long serialVersionUID = 1L;

    /**
     * @see HttpServlet#HttpServlet()
     */
    public SalaryList() {
        super();
        // TODO Auto-generated constructor stub
    }

    /**
     * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
     */
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // TODO Auto-generated method stub
        SalaryService service = new SalaryService();
        String currentPageStr =request.getParameter("currentPage");
        if(currentPageStr==null) currentPageStr="1";
        int currentPage = Integer.parseInt(currentPageStr);
        int currentCount=4;
        Long count = null;
        PageBean<Position> pageBean = null;
        List<Salary> staffList = null;
        try {
            pageBean = service.findPageBean(currentPage,currentCount);
            staffList = service.findAll();
            count = service.Count();
            request.setAttribute("pageBean", pageBean);
            request.setAttribute("salaryList", staffList);
            request.setAttribute("count", count);
            request.getRequestDispatcher("view/views/user/salary/staff.jsp").forward(request, response);
        }catch (SQLException e) {
            e.printStackTrace();
        }
    }

    /**
     * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
     */
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // TODO Auto-generated method stub
        doGet(request, response);
    }
}

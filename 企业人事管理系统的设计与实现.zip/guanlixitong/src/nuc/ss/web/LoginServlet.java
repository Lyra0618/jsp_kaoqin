package nuc.ss.web;

import java.io.IOException;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import nuc.ss.domain.Staff;
import nuc.ss.service.UserService;

/**
 * 登录
 * Servlet implementation class LoginServlet
 */
public class LoginServlet extends HttpServlet {
	//定义一个唯一标识符，用于控制序列化版本。
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public LoginServlet() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * 处理 GET 请求的方法
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// 设置请求的字符编码为 UTF-8
		request.setCharacterEncoding("utf-8");

		// 获取请求参数中的用户名和密码
		String name = request.getParameter("name");
		String password = request.getParameter("password");

		// 创建 UserService 对象，用于处理业务逻辑
		UserService service = new UserService();
		Staff user = null;

		try {
			// 调用 UserService 的 login 方法进行用户认证
			user = service.login(name, password);
		} catch (SQLException e) {
			// 捕获 SQL 异常并打印堆栈信息
			e.printStackTrace();
		}

		// 检查用户认证结果
		if (user != null) {
			// 用户认证成功，将用户信息存入 Session
			//用户名
			request.getSession().setAttribute("name", name);
			//用户的唯一标识
			request.getSession().setAttribute("userId", user.getId());
			//包含用户完整信息的对象
			request.getSession().setAttribute("loginUser", user);

			// 根据用户名是否为 admin，重定向到不同的页面
			if (name.equals("admin")) {
				response.sendRedirect(request.getContextPath() + "/view/views/index.jsp");
			} else {
				response.sendRedirect(request.getContextPath() + "/view/views/index_user.jsp");
			}
		} else {
			// 用户认证失败，重定向到错误页面
			response.sendRedirect(request.getContextPath() + "/view/views/error.jsp");
		}
	}

	/**
	 * 处理 POST 请求的方法
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// 调用 doGet 方法处理 POST 请求
		doGet(request, response);
	}

}

package nuc.ss.web;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import nuc.ss.domain.Staff;
import nuc.ss.service.StaffService;

/**
 * 修改人员
 * Servlet implementation class StaffEdit
 */
public class StaffEdit extends HttpServlet {
	//定义一个唯一标识符，用于控制序列化版本。
	private static final long serialVersionUID = 1L;

    /**
     * @see HttpServlet#HttpServlet()
     */
    public StaffEdit() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("UTF-8");
		String id = request.getParameter("id");
		String name = request.getParameter("name");
		String gender = request.getParameter("gender");
		String hiredate = request.getParameter("hireDate");
		String resDate = request.getParameter("resDate");
		String salary = request.getParameter("salary");
		String postId = request.getParameter("postId");
		String deptId = request.getParameter("deptId");
		StaffService service = new StaffService();
		try {
			Staff staff = new Staff();
			staff.setId(Integer.parseInt(id));
			staff.setName(name);
			staff.setGender(gender);
			staff.setHireDate(hiredate);
			staff.setResDate(resDate);
			staff.setSalary(salary);
			staff.setPostId(postId);
			staff.setDeptId(deptId);
			service.update(staff);
			Thread.sleep(3000);
			response.sendRedirect(request.getContextPath() + "/StaffList");
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}

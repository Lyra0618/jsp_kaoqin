package nuc.ss.web;

import nuc.ss.domain.Department;
import nuc.ss.service.DepartmentService;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.sql.SQLException;

/**
 * 部门新增
 * @author
 * @date 2024年06月24日 16:00
 */
public class DeptAdd extends HttpServlet {
    //定义一个唯一标识符，用于控制序列化版本。
    private static final long serialVersionUID = 1L;

    /**
     * @see HttpServlet#HttpServlet()
     */
    public DeptAdd() {
        super();
        // TODO Auto-generated constructor stub
    }

    /**
     * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
     *      response)
     */
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        // TODO Auto-generated method stub
        request.setCharacterEncoding("UTF-8");

        String name = request.getParameter("name");
        String parentId = request.getParameter("parentId");
        String depPath = request.getParameter("depPath");

        DepartmentService service = new DepartmentService();
        try {
            Department department = new Department();
            department.setParentId(Long.valueOf(parentId));
            department.setName(name);
            department.setDepPath(depPath);
            department.setEnabled(1);
            department.setIsParent(0);
            service.add(department);
        } catch (SQLException e) {
            e.printStackTrace();
        }
        try {
            Thread.sleep(3000);
            response.sendRedirect(request.getContextPath() + "/DeptList");
        } catch (Exception e) {
        }
    }

    /**
     * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
     *      response)
     */
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        // TODO Auto-generated method stub
        doGet(request, response);
    }

}

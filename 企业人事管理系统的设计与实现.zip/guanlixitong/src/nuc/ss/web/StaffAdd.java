package nuc.ss.web;

import java.io.IOException;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import nuc.ss.domain.Staff;
import nuc.ss.service.StaffService;

/**
 * 人员新增
 * Servlet implementation class StaffAdd
 */
public class StaffAdd extends HttpServlet {
	//定义一个唯一标识符，用于控制序列化版本。
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public StaffAdd() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	//protected 允许同一个包内的类以及子类访问。
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		//设置请求的字符编码为 UTF-8，确保正确处理请求参数中的非 ASCII 字符。
		request.setCharacterEncoding("UTF-8");
		//从 HttpServletRequest 对象中获取表单提交的各个参数值，并将它们存储在相应的变量中。
		String name = request.getParameter("name");
		String gender = request.getParameter("gender");
		String hiredate = request.getParameter("hireDate");
		String resDate = request.getParameter("resDate");
		String salary = request.getParameter("salary");
		String deptId = request.getParameter("deptId");
		String postId = request.getParameter("postId");
		String userName = request.getParameter("userName");
		String password = request.getParameter("password");
		//创建 StaffService 对象：用于调用业务逻辑方法。
		StaffService service = new StaffService();
		try {
			Staff staff = new Staff();
			staff.setName(name);
			staff.setGender(gender);
			staff.setHireDate(hiredate);
			staff.setResDate(resDate);
			staff.setSalary(salary);
			staff.setDeptId(deptId);
			staff.setPostId(postId);
			staff.setUserName(userName);
			staff.setPassword(password);
			service.add(staff);
		} catch (SQLException e) {
			e.printStackTrace();
		}

		try {
			//暂停三秒，模拟处理时间
			Thread.sleep(3000);
			//当用户提交新员工信息后，重定向到员工列表页面，可以让用户立即看到添加的新员工，确认操作成功。
			response.sendRedirect(request.getContextPath() + "/StaffList");
		} catch (Exception e) {
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}

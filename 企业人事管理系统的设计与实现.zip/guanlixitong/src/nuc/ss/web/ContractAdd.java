package nuc.ss.web;

import nuc.ss.domain.Contract;
import nuc.ss.service.ContractService;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.sql.SQLException;

/**
 * 合同新增接口
 * @author
 * @date 2024年06月24日 16:00
 */
public class ContractAdd extends HttpServlet {
    //定义一个唯一标识符，用于控制序列化版本。
    private static final long serialVersionUID = 1L;

    /**
     * @see HttpServlet#HttpServlet()
     */
    public ContractAdd() {
        super();
        // TODO Auto-generated constructor stub
    }

    /**
     * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
     *      response)
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        // TODO Auto-generated method stub
        request.setCharacterEncoding("UTF-8");
        String contractCode = request.getParameter("contractCode");
        String contractType = request.getParameter("contractType");
        String beginDate = request.getParameter("beginDate");
        String endDate = request.getParameter("endDate");
        String staffId = request.getParameter("staffId");
        try {
            Contract contract = new Contract();
            contract.setContractCode(contractCode);
            contract.setContractType(contractType);
            contract.setBeginDate(beginDate);
            contract.setEndDate(endDate);
            contract.setStaffId(staffId);
            ContractService service = new ContractService();
            service.add(contract);
        } catch (SQLException e) {
            e.printStackTrace();
        }
        try {
            Thread.sleep(3000);
            response.sendRedirect(request.getContextPath() + "/ContractList");
        } catch (Exception e) {
        }
    }

    /**
     * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
     *      response)
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        // TODO Auto-generated method stub
        doGet(request, response);
    }

}

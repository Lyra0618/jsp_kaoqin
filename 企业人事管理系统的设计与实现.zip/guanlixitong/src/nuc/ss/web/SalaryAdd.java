package nuc.ss.web;

import nuc.ss.domain.Salary;
import nuc.ss.service.SalaryService;
import nuc.ss.utils.DateTimeUtils;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.sql.SQLException;

/**
 * 薪资新增
 * @author
 * @date 2024年06月24日 16:00
 */
public class SalaryAdd extends HttpServlet {
    //定义一个唯一标识符，用于控制序列化版本。
    private static final long serialVersionUID = 1L;

    /**
     * @see HttpServlet#HttpServlet()
     */
    public SalaryAdd() {
        super();
        // TODO Auto-generated constructor stub
    }

    /**
     * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
     *      response)
     */
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        // TODO Auto-generated method stub
        request.setCharacterEncoding("UTF-8");

        String money = request.getParameter("money");
        String type = request.getParameter("type");
        String employeeId = request.getParameter("employeeId");
        SalaryService service = new SalaryService();
        try {
            Salary salary = new Salary();
            salary.setType(type);
            salary.setMoney(money);
            salary.setEmployeeId(Long.valueOf(employeeId));
            salary.setCreateTime(DateTimeUtils.dateTimeNow("yyyy-MM-dd HH:mm:ss"));
            service.add(salary);
        } catch (SQLException e) {
            e.printStackTrace();
        }
        try {
            Thread.sleep(3000);
            response.sendRedirect(request.getContextPath() + "/SalaryList");
        } catch (Exception e) {
        }
    }

    /**
     * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
     *      response)
     */
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        // TODO Auto-generated method stub
        doGet(request, response);
    }

}

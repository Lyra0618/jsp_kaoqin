package nuc.ss.web;

import nuc.ss.domain.Position;
import nuc.ss.service.PositionService;
import nuc.ss.utils.DateTimeUtils;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.sql.SQLException;

/**
 * 职位新增
 * @author
 * @date 2024年06月24日 16:00
 */
public class PositionAdd extends HttpServlet {
    //定义一个唯一标识符，用于控制序列化版本。
    private static final long serialVersionUID = 1L;

    /**
     * @see HttpServlet#HttpServlet()
     */
    public PositionAdd() {
        super();
        // TODO Auto-generated constructor stub
    }

    /**
     * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
     *      response)
     */
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        // TODO Auto-generated method stub
        request.setCharacterEncoding("UTF-8");

        String name = request.getParameter("name");
        String enabled = request.getParameter("enabled");
        PositionService service = new PositionService();
        try {
            Position position = new Position();
            position.setName(name);
            position.setEnabled(enabled);
            position.setCreateDate(DateTimeUtils.getNowDate());
            service.add(position);
        } catch (SQLException e) {
            e.printStackTrace();
        }
        try {
            Thread.sleep(3000);
            response.sendRedirect(request.getContextPath() + "/PostList");
        } catch (Exception e) {
        }
    }

    /**
     * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
     *      response)
     */
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        // TODO Auto-generated method stub
        doGet(request, response);
    }

}

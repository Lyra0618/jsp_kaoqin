package nuc.ss.web;

import nuc.ss.service.UserService;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

/**
 * @author wanlei
 * @date 2024年06月27日 14:22
 */
public class UserUpdatePassword extends HttpServlet {

    private static final long serialVersionUID = 1L;

    /**
     * @see HttpServlet#HttpServlet()
     */
    public UserUpdatePassword() {
        super();
        // TODO Auto-generated constructor stub
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        request.setCharacterEncoding("UTF-8");
        String password = request.getParameter("password");
        String staffId = request.getParameter("id");
        UserService service = new UserService();
        try {
            service.updatePassword(staffId, password);
            response.sendRedirect(request.getContextPath()+"/view/views/login_resetPassword.jsp");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }


    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // TODO Auto-generated method stub
        doGet(request, response);
    }
}

package nuc.ss.web;

import nuc.ss.domain.Contract;
import nuc.ss.service.ContractService;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

/**
 * 合同编辑接口
 * @author
 * @date 2024年06月24日 16:30
 */
public class ContractEdit extends HttpServlet {
    //定义一个唯一标识符，用于控制序列化版本。
    private static final long serialVersionUID = 1L;

    /**
     * @see HttpServlet#HttpServlet()
     */
    public ContractEdit() {
        super();
        // TODO Auto-generated constructor stub
    }

    /**
     * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
     */
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        request.setCharacterEncoding("UTF-8");
        String id = request.getParameter("id");
        String contractCode = request.getParameter("contractCode");
        String contractType = request.getParameter("contractType");
        String beginDate = request.getParameter("beginDate");
        String endDate = request.getParameter("endDate");
        String staffId = request.getParameter("staffId");
        try {
            Contract contract = new Contract();
            contract.setContractCode(contractCode);
            contract.setContractType(contractType);
            contract.setBeginDate(beginDate);
            contract.setEndDate(endDate);
            contract.setStaffId(staffId);
            contract.setId(id);
            ContractService service = new ContractService();
            service.update(contract);
            Thread.sleep(3000);
            response.sendRedirect(request.getContextPath() + "/ContractList");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
     */
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // TODO Auto-generated method stub
        doGet(request, response);
    }

}

package nuc.ss.dao;

import nuc.ss.domain.Position;
import nuc.ss.utils.C3P0Utils;
import org.apache.commons.dbutils.QueryRunner;
import org.apache.commons.dbutils.handlers.BeanListHandler;
import org.apache.commons.dbutils.handlers.ScalarHandler;

import java.sql.SQLException;
import java.util.List;

/**
 * 岗位 操作数据库
 * @date 2024年06月24日 15:41
 */
public class PositionDao {

    /**
     * 查询总条数
     * @return 岗位总数
     * @throws SQLException
     */
    public Long Count() throws SQLException {
        QueryRunner qr = new QueryRunner(C3P0Utils.getDataSource()); // 使用C3P0连接池创建QueryRunner对象
        String sql = "select count(*) from position"; // SQL查询语句，查询岗位表的总条数
        Long count = (Long) qr.query(sql, new ScalarHandler()); // 执行查询并获取结果
        return count; // 返回查询结果
    }

    /**
     * 分页查询
     * @param index 起始索引
     * @param currentCount 每页显示的条数
     * @return 岗位列表
     * @throws SQLException
     */
    public List<Position> findAllPositionListForPageBean(int index, int currentCount) throws SQLException {
        QueryRunner qr = new QueryRunner(C3P0Utils.getDataSource()); // 使用C3P0连接池创建QueryRunner对象
        String sql = "select * from position order by id asc limit ?,? "; // SQL查询语句，分页查询岗位数据
        return qr.query(sql, new BeanListHandler<Position>(Position.class), index, currentCount); // 执行查询并返回结果列表
    }

    /**
     * 查询全部数据
     * @return 岗位列表
     * @throws SQLException
     */
    public List<Position> findAllPosition() throws SQLException {
        QueryRunner runner = new QueryRunner(C3P0Utils.getDataSource()); // 使用C3P0连接池创建QueryRunner对象
        String sql = "select * from position"; // SQL查询语句，查询所有岗位数据
        return runner.query(sql, new BeanListHandler<Position>(Position.class)); // 执行查询并返回结果列表
    }

    /**
     * 删除岗位
     * @param id 岗位ID
     * @throws SQLException
     */
    public void delete(String id) throws SQLException {
        QueryRunner qr = new QueryRunner(C3P0Utils.getDataSource()); // 使用C3P0连接池创建QueryRunner对象
        String sql = "delete from position where id=?"; // SQL删除语句，根据岗位ID删除岗位数据
        qr.update(sql, id); // 执行删除操作
    }

    /**
     * 添加岗位
     * @param j 岗位对象
     * @throws SQLException
     */
    public void add(Position j) throws SQLException {
        QueryRunner qr = new QueryRunner(C3P0Utils.getDataSource()); // 使用C3P0连接池创建QueryRunner对象
        String sql = "insert into position values (null,?,?,?)"; // SQL插入语句，插入新的岗位数据
        qr.update(sql, j.getName(), j.getCreateDate(), j.getEnabled()); // 执行插入操作
    }

    /**
     * 更新岗位
     * @param j 岗位对象
     * @throws SQLException
     */
    public void update(Position j) throws SQLException {
        QueryRunner qr = new QueryRunner(C3P0Utils.getDataSource()); // 使用C3P0连接池创建QueryRunner对象
        String sql = "update position set name=?,enabled=? where id=?"; // SQL更新语句，根据岗位ID更新岗位数据
        qr.update(sql, j.getName(), j.getEnabled(), j.getId()); // 执行更新操作
    }
}

package nuc.ss.dao;

import java.sql.SQLException;
import java.util.List;

import nuc.ss.domain.Staff;
import nuc.ss.utils.C3P0Utils;
import org.apache.commons.dbutils.QueryRunner;
import org.apache.commons.dbutils.handlers.BeanHandler;
import org.apache.commons.dbutils.handlers.BeanListHandler;
import org.apache.commons.dbutils.handlers.ScalarHandler;

/**
 * 员工管理
 */
public class StaffDao {

	/**
	 * 查询总条数
	 * @return 员工总数
	 * @throws SQLException
	 */
	public Long Count() throws SQLException {
		QueryRunner qr = new QueryRunner(C3P0Utils.getDataSource()); // 使用C3P0连接池创建QueryRunner对象
		String sql = "select count(*) from staff"; // SQL查询语句，查询员工表的总条数
		Long count = (Long) qr.query(sql, new ScalarHandler()); // 执行查询并获取结果
		return count; // 返回查询结果
	}

	/**
	 * 分页查询员工列表
	 * @param index 起始索引
	 * @param currentCount 每页显示的条数
	 * @return 员工列表
	 * @throws SQLException
	 */
	public List<Staff> findAllStaffListForPageBean(int index, int currentCount) throws SQLException {
		QueryRunner qr = new QueryRunner(C3P0Utils.getDataSource()); // 使用C3P0连接池创建QueryRunner对象
		String sql = "SELECT *,(SELECT name from department as de WHERE de.id = st.deptId) as deptName\n" +
				",(SELECT name from position as po WHERE po.id = st.postId) as postName\n" +
				"FROM `staff` as st order by st.id asc limit ?,?"; // SQL查询语句，分页查询员工数据，并获取deptName和postName
		return qr.query(sql, new BeanListHandler<Staff>(Staff.class), index, currentCount); // 执行查询并返回结果列表
	}

	/**
	 * 查询全部员工数据
	 * @return 员工列表
	 * @throws SQLException
	 */
	public List<Staff> findAllStaff() throws SQLException {
		QueryRunner qr = new QueryRunner(C3P0Utils.getDataSource()); // 使用C3P0连接池创建QueryRunner对象
		String sql = "select * from staff"; // SQL查询语句，查询所有员工数据
		return qr.query(sql, new BeanListHandler<Staff>(Staff.class)); // 执行查询并返回结果列表
	}

	/**
	 * 添加员工
	 * @param staff 员工对象
	 * @throws SQLException
	 */
	public void add(Staff staff) throws SQLException {
		QueryRunner qr = new QueryRunner(C3P0Utils.getDataSource()); // 使用C3P0连接池创建QueryRunner对象
		if (staff.getResDate() != null && !"".equals(staff.getResDate())) {
			String sql = "insert into staff values(null,?,?,?,?,?,?,?,?,?)"; // SQL插入语句，插入新的员工数据
			qr.update(sql, staff.getName(), staff.getGender(), staff.getHireDate(), staff.getResDate(), staff.getSalary(), staff.getDeptId(), staff.getPostId(), staff.getUserName(), staff.getPassword()); // 执行插入操作
		} else {
			String sql = "insert into staff values(null,?,?,?,?,?,?,?,?,?)"; // SQL插入语句，不插入resDate字段
			qr.update(sql, staff.getName(), staff.getGender(), staff.getHireDate(), null, staff.getSalary(), staff.getDeptId(), staff.getPostId(), staff.getUserName(), staff.getPassword()); // 执行插入操作
		}
	}

	/**
	 * 删除员工
	 * @param id 员工ID
	 * @throws SQLException
	 */
	public void delete(String id) throws SQLException {
		QueryRunner qr = new QueryRunner(C3P0Utils.getDataSource()); // 使用C3P0连接池创建QueryRunner对象
		String sql = "delete from staff where id=?"; // SQL删除语句，根据员工ID删除员工数据
		qr.update(sql, id); // 执行删除操作
	}

	/**
	 * 更新员工
	 * @param staff 员工对象
	 * @throws SQLException
	 */
	public void update(Staff staff) throws SQLException {
		QueryRunner qr = new QueryRunner(C3P0Utils.getDataSource()); // 使用C3P0连接池创建QueryRunner对象
		if (staff.getResDate() != null && !"".equals(staff.getResDate()) && staff.getResDate().length() > 0) {
			String sql = "update staff set name = ?, gender = ?,hireDate = ?, resDate = ?, salary = ?, deptId = ?, postId = ?  where id=?"; // SQL更新语句，更新员工数据，包括resDate字段
			qr.update(sql, staff.getName(), staff.getGender(), staff.getHireDate(), staff.getResDate(), staff.getSalary(), staff.getDeptId(), staff.getPostId(), staff.getId()); // 执行更新操作
		} else {
			String sql = "update staff set name = ?, gender = ?,hireDate = ?,resDate = ?, salary = ?, deptId = ?, postId = ?  where id=?"; // SQL更新语句，更新员工数据，不包括resDate字段
			qr.update(sql, staff.getName(), staff.getGender(), staff.getHireDate(), null, staff.getSalary(), staff.getDeptId(), staff.getPostId(), staff.getId()); // 执行更新操作
		}
	}

	/**
	 * 根据ID查找员工
	 * @param id 员工ID
	 * @return 员工对象
	 * @throws SQLException
	 */
	public Staff findById(Long id) throws SQLException {
		QueryRunner qr = new QueryRunner(C3P0Utils.getDataSource()); // 使用C3P0连接池创建QueryRunner对象
		String sql = "select * from staff where id = id"; // SQL查询语句，根据员工ID查询员工数据
		return qr.query(sql, new BeanHandler<Staff>(Staff.class)); // 执行查询并返回员工对象
	}
}

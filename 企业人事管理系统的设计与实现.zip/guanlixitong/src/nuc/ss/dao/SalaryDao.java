package nuc.ss.dao;

import nuc.ss.domain.Salary;
import nuc.ss.utils.C3P0Utils;
import org.apache.commons.dbutils.QueryRunner;
import org.apache.commons.dbutils.handlers.BeanListHandler;
import org.apache.commons.dbutils.handlers.ScalarHandler;

import java.sql.SQLException;
import java.util.List;

/**
 * 薪资 操作数据库
 * @date 2024年06月25日 15:17
 */
public class SalaryDao {

    /**
     * 查询总条数
     * @return 薪资记录总数
     * @throws SQLException
     */
    public Long Count() throws SQLException {
        QueryRunner qr = new QueryRunner(C3P0Utils.getDataSource()); // 使用C3P0连接池创建QueryRunner对象
        String sql = "select count(*) from salary"; // SQL查询语句，查询薪资表的总条数
        Long count = (Long) qr.query(sql, new ScalarHandler()); // 执行查询并获取结果
        return count; // 返回查询结果
    }

    /**
     * 分页查询
     * @param index 起始索引
     * @param currentCount 每页显示的条数
     * @return 薪资列表
     * @throws SQLException
     */
    public List<Salary> findAllsalaryListForPageBean(int index, int currentCount) throws SQLException {
        QueryRunner qr = new QueryRunner(C3P0Utils.getDataSource()); // 使用C3P0连接池创建QueryRunner对象
        String sql = "SELECT *,(SELECT name from staff as st where st.id = sa.employeeId) as employeeName FROM salary as sa" +
                " order by sa.id asc limit ?,? "; // SQL查询语句，分页查询薪资数据，并获取employeeName
        return qr.query(sql, new BeanListHandler<Salary>(Salary.class), index, currentCount); // 执行查询并返回结果列表
    }

    /**
     * 查询全部数据
     * @return 薪资列表
     * @throws SQLException
     */
    public List<Salary> findAllsalary() throws SQLException {
        QueryRunner runner = new QueryRunner(C3P0Utils.getDataSource()); // 使用C3P0连接池创建QueryRunner对象
        String sql = "select * from salary"; // SQL查询语句，查询所有薪资数据
        return runner.query(sql, new BeanListHandler<Salary>(Salary.class)); // 执行查询并返回结果列表
    }

    /**
     * 删除薪资记录
     * @param id 薪资记录ID
     * @throws SQLException
     */
    public void delete(String id) throws SQLException {
        QueryRunner qr = new QueryRunner(C3P0Utils.getDataSource()); // 使用C3P0连接池创建QueryRunner对象
        String sql = "delete from salary where id=?"; // SQL删除语句，根据薪资记录ID删除薪资数据
        qr.update(sql, id); // 执行删除操作
    }

    /**
     * 添加薪资记录
     * @param j 薪资对象
     * @throws SQLException
     */
    public void add(Salary j) throws SQLException {
        QueryRunner qr = new QueryRunner(C3P0Utils.getDataSource()); // 使用C3P0连接池创建QueryRunner对象
        String sql = "insert into salary values (null,?,?,?,?)"; // SQL插入语句，插入新的薪资数据
        qr.update(sql, j.getMoney(), j.getType(), j.getEmployeeId(), j.getCreateTime()); // 执行插入操作
    }

    /**
     * 更新薪资记录
     * @param j 薪资对象
     * @throws SQLException
     */
    public void update(Salary j) throws SQLException {
        QueryRunner qr = new QueryRunner(C3P0Utils.getDataSource()); // 使用C3P0连接池创建QueryRunner对象
        String sql = "update salary set money=?,type=?,employeeId=? where id=?"; // SQL更新语句，根据薪资记录ID更新薪资数据
        qr.update(sql, j.getMoney(), j.getType(), j.getEmployeeId(), j.getId()); // 执行更新操作
    }
}

package nuc.ss.dao;

import java.sql.SQLException;

import nuc.ss.domain.Staff;
import nuc.ss.utils.C3P0Utils;
import org.apache.commons.dbutils.QueryRunner;
import org.apache.commons.dbutils.handlers.BeanHandler;

/**
 * 用户登录
 */
public class UserDao {

	/**
	 * 用户登录
	 * @param name 用户名
	 * @param password 密码
	 * @return Staff 用户对象
	 * @throws SQLException
	 */
	public Staff login(String name, String password) throws SQLException {
		QueryRunner runner = new QueryRunner(C3P0Utils.getDataSource()); // 使用C3P0连接池创建QueryRunner对象
		String sql = "select * from staff where userName=? and password=?"; // SQL查询语句，根据用户名和密码查询用户
		Staff user = runner.query(sql, new BeanHandler<Staff>(Staff.class), name, password); // 执行查询并获取用户对象
		return user; // 返回查询到的用户对象
	}

	/**
	 * 修改密码
	 * @param staffId 员工ID
	 * @param password 新密码
	 * @throws SQLException
	 */
	public void updatePassword(String staffId, String password) throws SQLException {
		QueryRunner qr = new QueryRunner(C3P0Utils.getDataSource()); // 使用C3P0连接池创建QueryRunner对象
		String sql = "UPDATE staff SET `password` = ? WHERE id = ?"; // SQL更新语句，根据员工ID更新密码
		qr.update(sql, password, staffId); // 执行更新操作
	}
}

/*
Navicat MySQL Data Transfer

Source Server         : jsp_kaoqin
Source Server Version : 80033
Source Host           : localhost:3306
Source Database       : jsp_kaoqin

Target Server Type    : MYSQL
Target Server Version : 80033
File Encoding         : 65001

Date: 2024-09-13 11:14:13
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for contract
-- ----------------------------
DROP TABLE IF EXISTS `contract`;
CREATE TABLE `contract` (
  `id` int NOT NULL AUTO_INCREMENT,
  `staffId` int DEFAULT NULL COMMENT '员工编号',
  `contractCode` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '合同编码',
  `contractType` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '合同类型',
  `beginDate` date DEFAULT NULL COMMENT '开始日期',
  `endDate` date DEFAULT NULL COMMENT '结束日期',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci ROW_FORMAT=DYNAMIC;

-- ----------------------------
-- Records of contract
-- ----------------------------
INSERT INTO `contract` VALUES ('1', '1', '2024-NDA-001', '保密协议', '2024-06-06', '2030-08-13');
INSERT INTO `contract` VALUES ('2', '4', '2024-PUR-002', '采购合同', '2024-06-25', '2024-10-24');
INSERT INTO `contract` VALUES ('3', '2', '2024-SH-003', '销售合同', '2024-06-03', '2024-07-18');
INSERT INTO `contract` VALUES ('4', '3', '2024-SER-004', '服务合同', '2024-07-05', '2024-12-05');

-- ----------------------------
-- Table structure for department
-- ----------------------------
DROP TABLE IF EXISTS `department`;
CREATE TABLE `department` (
  `id` int NOT NULL AUTO_INCREMENT COMMENT '主键id',
  `name` varchar(32) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL COMMENT '部门名称',
  `parentId` int DEFAULT NULL,
  `depPath` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL,
  `enabled` tinyint(1) DEFAULT '1',
  `isParent` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8mb3 ROW_FORMAT=DYNAMIC COMMENT='部门';

-- ----------------------------
-- Records of department
-- ----------------------------
INSERT INTO `department` VALUES ('1', '股东会', '-1', '.1', '1', '1');
INSERT INTO `department` VALUES ('2', '总办', '1', '.1.2', '1', '1');
INSERT INTO `department` VALUES ('3', '市场部', '2', '.1.2.3', '1', '1');
INSERT INTO `department` VALUES ('4', '华北市场部', '3', '.1.2.3.4', '1', '1');
INSERT INTO `department` VALUES ('5', '华南市场部', '3', '.1.2.3.5', '1', '0');
INSERT INTO `department` VALUES ('6', '石家庄市场部', '4', '.1.2.3.4.6', '1', '0');
INSERT INTO `department` VALUES ('7', '西北市场部', '3', '.1.2.3.7', '1', '1');
INSERT INTO `department` VALUES ('8', '西安市场', '7', '.1.2.3.7.8', '1', '1');
INSERT INTO `department` VALUES ('9', '莲湖区市场', '8', '.1.2.3.7.8.9', '1', '0');
INSERT INTO `department` VALUES ('10', '技术部', '2', '.1.2.10', '1', '0');
INSERT INTO `department` VALUES ('11', '运维部', '2', '.1.2.11', '1', '1');
INSERT INTO `department` VALUES ('12', '运维1部', '11', '.1.2.11.12', '1', '0');
INSERT INTO `department` VALUES ('13', '运维2部', '11', '.1.2.11.13', '1', '0');
INSERT INTO `department` VALUES ('14', '人力资源部', '2', '.1.2.14', '1', '0');

-- ----------------------------
-- Table structure for position
-- ----------------------------
DROP TABLE IF EXISTS `position`;
CREATE TABLE `position` (
  `id` int NOT NULL AUTO_INCREMENT COMMENT '主键id',
  `name` varchar(32) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL COMMENT '职位名称',
  `createDate` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '创建时间',
  `enabled` tinyint(1) DEFAULT '1',
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE KEY `idx_name` (`name`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb3 ROW_FORMAT=DYNAMIC COMMENT='职位';

-- ----------------------------
-- Records of position
-- ----------------------------
INSERT INTO `position` VALUES ('1', '技术总监', '2024-06-28 21:13:42', '1');
INSERT INTO `position` VALUES ('2', '运营总监', '2024-06-28 21:43:48', '1');
INSERT INTO `position` VALUES ('3', '市场总监', '2024-06-28 00:00:00', '1');
INSERT INTO `position` VALUES ('4', '研发工程师', '2024-01-14 00:00:00', '1');
INSERT INTO `position` VALUES ('5', '运维工程师', '2024-01-14 16:11:41', '1');
INSERT INTO `position` VALUES ('6', 'Java研发经理', '2024-06-30 00:00:00', '1');

-- ----------------------------
-- Table structure for salary
-- ----------------------------
DROP TABLE IF EXISTS `salary`;
CREATE TABLE `salary` (
  `id` int NOT NULL AUTO_INCREMENT,
  `money` decimal(10,2) DEFAULT NULL COMMENT '金额',
  `type` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '类型  奖金 扣款',
  `employeeId` int DEFAULT NULL,
  `createTime` datetime DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci ROW_FORMAT=DYNAMIC;

-- ----------------------------
-- Records of salary
-- ----------------------------
INSERT INTO `salary` VALUES ('1', '111.00', '01', '1', '2024-06-15 14:23:56');
INSERT INTO `salary` VALUES ('2', '3000.00', '02', '2', '2024-09-13 10:25:55');
INSERT INTO `salary` VALUES ('3', '111.00', '02', '1', '2024-06-25 16:29:13');

-- ----------------------------
-- Table structure for staff
-- ----------------------------
DROP TABLE IF EXISTS `staff`;
CREATE TABLE `staff` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL,
  `gender` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL COMMENT '性别',
  `hireDate` date DEFAULT NULL COMMENT '入职时间',
  `resDate` date DEFAULT NULL COMMENT '离职时间',
  `salary` decimal(10,2) DEFAULT NULL COMMENT '薪资',
  `deptId` int DEFAULT NULL,
  `postId` int DEFAULT NULL,
  `userName` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL,
  `password` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb3 ROW_FORMAT=DYNAMIC;

-- ----------------------------
-- Records of staff
-- ----------------------------
INSERT INTO `staff` VALUES ('1', '任骁睿', '0', '2024-06-25', null, '8520.00', '1', '1', 'admin', '123456');
INSERT INTO `staff` VALUES ('2', '小张越', '0', '2024-06-25', null, '6000.00', '5', '2', 'xzy', '123456');
INSERT INTO `staff` VALUES ('3', '韩佩锦', '0', '2024-06-25', null, '2500.00', '1', '4', 'hpj', '123456');
INSERT INTO `staff` VALUES ('4', '大张越', '0', '2024-06-17', '2024-06-12', '5000.00', '1', '5', 'dzy', '111111');
INSERT INTO `staff` VALUES ('5', '盖尔利', '1', '2024-06-04', '2024-06-12', '6500.00', '1', '6', 'grl', '111111');
INSERT INTO `staff` VALUES ('6', '特蕾莎', '1', '2024-06-05', '2024-06-12', '5555.00', '1', '2', 'teresa', '111111');
